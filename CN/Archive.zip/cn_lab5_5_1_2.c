// cs20b1107, sriram reddy
//  Go back N, Server Protocol
