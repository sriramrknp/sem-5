for (int i = 0; i < arr.size(); i++)
    // {

    // }